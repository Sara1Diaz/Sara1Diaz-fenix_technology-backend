const Usuario = require('../models/Usuario');
const router = require('express').Router();

// Obtener todos los usuarios
router.get("/", async (req, res) => {
    try {
        const usuarios = await Usuario.findAll();
        res.json({ message: "Usuarios obtenidos correctamente.", data: usuarios });
    } catch (error) {
        console.error("Error al obtener los usuarios:", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
});


// Obtener un solo usuario por su ID
router.get("/:id", async (req, res) => {
    const { id } = req.params;
    try {
        const usuario = await Usuario.findByPk(id);
        if (!usuario) {
            return res.status(404).json({ error: "Usuario no encontrado." });
        }
        res.json({ message: "Usuario obtenido correctamente.", data: usuario });
    } catch (error) {
        console.error("Error al obtener el usuario:", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
});



// Crear un nuevo usuario
router.post("/", async (req, res) => {
    // Verificar si los campos requeridos están presentes en la solicitud
    const { PK_fk_Id_tdoc, Numero_documento, Primer_nombre, Segundo_nombre, Primer_apellido, Segundo_apellido, Telefono_contacto, Email, Pk_fk_Id_Cod_rol, Clave, Estado_usuario } = req.body;
    if (!PK_fk_Id_tdoc || !Numero_documento || !Primer_nombre || !Segundo_nombre || !Primer_apellido || !Segundo_apellido || !Telefono_contacto || !Email || !Pk_fk_Id_Cod_rol || !Clave || !Estado_usuario) {
        return res.status(400).json({ error: "Uno o más campos requeridos están vacíos." });
    }

    try {
        const usuario = await Usuario.create({
            PK_fk_Id_tdoc,
            Numero_documento,
            Primer_nombre,
            Segundo_nombre,
            Primer_apellido,
            Segundo_apellido,
            Telefono_contacto,
            Email,
            Pk_fk_Id_Cod_rol,
            Clave,
            Estado_usuario
        });
        res.status(201).json({ message: "Usuario creado correctamente.", data: usuario });
    } catch (error) {
        console.error("Error al crear el usuario:", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
});


// Actualizar un usuario por su ID
router.put("/:id", async (req, res) => {
    const { id } = req.params;
    const newData = req.body;
    try {
        const usuario = await Usuario.findByPk(id);
        if (!usuario) {
            return res.status(404).json({ error: "Usuario no encontrado." });
        }
        await usuario.update(newData);
        res.json({ message: "Usuario actualizado correctamente.", data: usuario });
    } catch (error) {
        console.error("Error al actualizar el usuario:", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
});


// Eliminar un usuario por su ID
router.delete("/:id", async (req, res) => {
    const { id } = req.params;
    try {
        const usuario = await Usuario.findByPk(id);
        if (!usuario) {
            return res.status(404).json({ error: "Usuario no encontrado." });
        }
        await usuario.destroy();
        res.status(204).json({ message: "Usuario eliminado correctamente." });
    } catch (error) {
        console.error("Error al eliminar el usuario:", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
});

module.exports = router;
