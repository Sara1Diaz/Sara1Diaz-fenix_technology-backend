const Reportesalida = require('../models/Reportesalida');
const router = require('express').Router();

// Obtener todos los reportes de salida
router.get("/", async (req, res) => {
    try {
        const reportesalida = await Reportesalida.findAll();
        if (!reportesalida || reportesalida.length === 0) {
            return res.status(404).json({ mensaje: "No se encontraron reportesalida." });
        }
        res.status(200).json({ mensaje: "reporte salida obtenidos correctamente", reportesalida });
    } catch (error) {
        console.error("Error al obtener los reportesalida:", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
});



// Obtener un solo reportesalida por su ID
router.get("/:id", async (req, res) => {
    const { id } = req.params;
    try {
        const reportesalida = await Reportesalida.findByPk(id);
        if (!reportesalida) {
            return res.status(404).json({ error: "reporte salida no encontrado." });
        }
        res.status(200).json({ mensaje: "reporte salida obtenido exitosamente", reportesalida });
    } catch (error) {
        console.error("Error al obtener el reporte salida:", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
});

// Crear un nuevo reporte de salida
router.post("/", async (req, res) => {
    // Verificar si los campos requeridos están presentes en la solicitud
    const { Fecha_emision, PK_fk_numlocal_destino, Descripcion_salida } = req.body;
    if ( !Fecha_emision || !PK_fk_numlocal_destino || !Descripcion_salida) {
        return res.status(400).json({ error: "Uno o más campos requeridos están vacíos." });
    }

    try {
        const reportesalida = await Reportesalida.create({
            Fecha_emision,
            PK_fk_numlocal_destino,
            Descripcion_salida
        });
        return res.status(201).json({ mensaje: "Reporte de salida creado correctamente", reportesalida });
    } catch (error) {
        console.error("Error al crear el reporte de salida:", error);
        return res.status(500).json({ error: "Error interno del servidor." });
    }
});


// Actualizar un reporte de salida por su Id_salida
router.put("/:id", async (req, res) => {
    const { id } = req.params;
    const newData = req.body;
    try {
        const reportesalida = await Reportesalida.findByPk(id);
        if (!reportesalida) {
            return res.status(404).json({ error: "Reporte de salida no encontrado." });
        }
        await reportesalida.update(newData);
        console.log("Datos actualizados correctamente.");
        return res.status(200).json({ message: "Datos actualizados correctamente.", reportesalida });
    } catch (error) {
        console.error("Error al actualizar el reporte de salida:", error);
        return res.status(500).json({ error: "Error interno del servidor." });
    }
});


// Eliminar una reporte salida por su ID
router.delete("/:id", async (req, res) => {
    const { id } = req.params;
    try {
        const reportesalida = await Reportesalida.findByPk(id);
        if (!reportesalida) {
            return res.status(404).json({ error: "reporte salida no encontrada." });
        }
        await reportesalida.destroy();
        res.status(200).json({ mensaje: "reporte salida eliminada exitosamente." });
    } catch (error) {
        console.error("Error al eliminar la reporte salida:", error);
        res.status(500).json({ error: "Error interno del servidor." });
    }
});



module.exports = router;
