const express = require("express");
const cors = require("cors");
const usuario = require("./routes/usuario");
const producto = require("./routes/producto");
const tipodocumento = require("./routes/tipodocumento");
const bodega = require("./routes/bodega");
const tipomovimiento = require("./routes/tipomovimiento");
const rol = require("./routes/rol");
const reportepedido = require("./routes/reportepedido");
const movimientoinventario = require("./routes/movimientoinventario");
const marcaproducto = require("./routes/marcaproducto");
const envio = require("./routes/envio");
const detalledevolucionlocal = require("./routes/detalledevolucionlocal");
const detallereporteentrada = require("./routes/detallereporteentrada");
const detallereportepedido = require("./routes/detallereportepedido");
const detallereportesalida = require("./routes/detallereportesalida");
const local = require("./routes/local");
const reportedevolucionlocal = require("./routes/reportedevolucionlocal");
const reporteentrada = require("./routes/reporteentrada");
const reportesalida = require("./routes/reportesalida");

const db = require("./db/database");
const app = express();
const port = process.env.PORT || 3030;



(async () => {

    try {
        await db.authenticate()
        db.sync();
        console.log("Base de datos conectada");
    } catch (error) {
        throw new Error(error);
    }
})();

//middleware
app.use(express.json());//recibir informacion
app.use(cors());//habilitar otras aplicaciones para realizar solicitudes a nuestra app

app.use("/usuario", usuario);
app.use("/producto", producto);
app.use("/tipodocumento", tipodocumento);
app.use("/bodega", bodega);
app.use("/tipomovimiento", tipomovimiento);
app.use("/rol", rol);
app.use("/reportepedido", reportepedido);
app.use("/movimientoinventario", movimientoinventario);
app.use("/marcaproducto", marcaproducto);
app.use("/envio", envio);
app.use("/detalledevolucionlocal", detalledevolucionlocal)
app.use("/detallereporteentrada", detallereporteentrada)
app.use("/detallereportepedido", detallereportepedido)
app.use("/detallereportesalida", detallereportesalida)
app.use("/local", local)
app.use("/reportedevolucionlocal", reportedevolucionlocal)
app.use("/reporteentrada", reporteentrada)
app.use("/reportesalida", reportesalida)




app.listen(port, () => {
    console.log("servidor ejecutandose en el puerto:", port);
});