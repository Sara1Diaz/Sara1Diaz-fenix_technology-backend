'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class DetalleReporteEntrada extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  DetalleReporteEntrada.init({
    Id_Detalle_reporte_entrada: DataTypes.INTEGER,
    PK_fk_Id_entrada: DataTypes.INTEGER,
    PK_fk_Id_bodega_destino: DataTypes.INTEGER,
    PK_fk_Id_producto: DataTypes.INTEGER,
    Cantidad_total_entradas: DataTypes.INTEGER,
    Valor_entradas: DataTypes.BIGINT,
    Subtotal_entradas: DataTypes.BIGINT
  }, {
    sequelize,
    modelName: 'DetalleReporteEntrada',
  });
  return DetalleReporteEntrada;
};