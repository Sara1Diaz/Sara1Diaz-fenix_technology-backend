'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Local extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Local.init({
    Num_local: DataTypes.INTEGER,
    Centro_comercial: DataTypes.STRING,
    PK_fk_Id_usuariovendedor: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Local',
  });
  return Local;
};