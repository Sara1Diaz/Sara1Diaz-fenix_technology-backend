'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class DetalleReportePedido extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  DetalleReportePedido.init({
    Id_detalle_pedido: DataTypes.INTEGER,
    Pk_fk_id_pedido: DataTypes.INTEGER,
    Metodo_pago: DataTypes.STRING,
    Pk_fk_Idproducto: DataTypes.INTEGER,
    Cantidad_producto: DataTypes.INTEGER,
    Valor_producto: DataTypes.BIGINT,
    Total_pedido: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'DetalleReportePedido',
  });
  return DetalleReportePedido;
};