'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class ReportePedido extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  ReportePedido.init({
    Id_pedido: DataTypes.INTEGER,
    Pk_fk_numlocal: DataTypes.INTEGER,
    Pk_fk_Id_envio: DataTypes.INTEGER,
    Fecha_emision: DataTypes.DATE,
    Nombre_cliente: DataTypes.STRING,
    Apellido_cliente: DataTypes.STRING,
    Telefono_cliente: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'ReportePedido',
  });
  return ReportePedido;
};