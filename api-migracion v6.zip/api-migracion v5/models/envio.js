'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Envio extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Envio.init({
    Id_envio: DataTypes.INTEGER,
    Pk_fk_id_pedido: DataTypes.INTEGER,
    Tipo_envio: DataTypes.STRING,
    Nom_transportadora: DataTypes.STRING,
    Ciudad_envio: DataTypes.STRING,
    Direccion_entrega: DataTypes.STRING,
    Valor_envio: DataTypes.BIGINT,
    Fecha_estimada_entrega_pedido: DataTypes.DATE
  }, {
    sequelize,
    modelName: 'Envio',
  });
  return Envio;
};