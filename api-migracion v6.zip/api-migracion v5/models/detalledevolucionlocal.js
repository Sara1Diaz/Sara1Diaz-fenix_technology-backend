'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class DetalleDevolucionLocal extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  DetalleDevolucionLocal.init({
    Id_detalle_devolucion: DataTypes.INTEGER,
    PK_fk_Id_devolucion: DataTypes.INTEGER,
    PK_fk_Id_bodega_destino: DataTypes.INTEGER,
    PK_fk_Id_producto: DataTypes.INTEGER,
    Cantidad_devuelta: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'DetalleDevolucionLocal',
  });
  return DetalleDevolucionLocal;
};