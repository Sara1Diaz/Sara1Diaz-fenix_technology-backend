'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Producto extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Producto.init({
    Id_producto: DataTypes.INTEGER,
    PK_fk_Id_marca_producto: DataTypes.INTEGER,
    Modelo_producto: DataTypes.STRING,
    Tipo_producto: DataTypes.STRING,
    Color_producto: DataTypes.STRING,
    Precio_producto: DataTypes.BIGINT,
    Talla_disponible_producto: DataTypes.STRING,
    Cantidad_disponible_producto: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Producto',
  });
  return Producto;
};