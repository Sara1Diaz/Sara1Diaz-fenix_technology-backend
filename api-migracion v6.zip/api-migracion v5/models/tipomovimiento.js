'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class TipoMovimiento extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  TipoMovimiento.init({
    Id_tp_movimiento: DataTypes.INTEGER,
    Descrip_tp_movimiento: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'TipoMovimiento',
  });
  return TipoMovimiento;
};