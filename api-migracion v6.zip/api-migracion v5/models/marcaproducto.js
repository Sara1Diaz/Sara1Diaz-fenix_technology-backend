'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class MarcaProducto extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  MarcaProducto.init({
    Id_marca_producto: DataTypes.INTEGER,
    Nom_marca_producto: DataTypes.STRING,
    Estado_marca_producto: DataTypes.BOOLEAN
  }, {
    sequelize,
    modelName: 'MarcaProducto',
  });
  return MarcaProducto;
};