'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class MovimientoInventario extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  MovimientoInventario.init({
    Id_movimiento: DataTypes.INTEGER,
    PK_fk_Id_producto: DataTypes.INTEGER,
    PK_fk_Id_tmovimiento: DataTypes.STRING,
    Fecha_movimiento: DataTypes.DATE
  }, {
    sequelize,
    modelName: 'MovimientoInventario',
  });
  return MovimientoInventario;
};