'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Usuario extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Usuario.init({
    PK_fk_Id_tdoc: DataTypes.INTEGER,
    Numero_documento: DataTypes.INTEGER,
    Primer_nombre: DataTypes.STRING,
    Segundo_nombre: DataTypes.STRING,
    Primer_apellido: DataTypes.STRING,
    Segundo_apellido: DataTypes.STRING,
    Telefono_contacto: DataTypes.INTEGER,
    Email: DataTypes.STRING,
    Pk_fk_Id_Cod_rol: DataTypes.INTEGER,
    Clave: DataTypes.STRING,
    Estado_usuario: DataTypes.BOOLEAN
  }, {
    sequelize,
    modelName: 'Usuario',
  });
  return Usuario;
};

