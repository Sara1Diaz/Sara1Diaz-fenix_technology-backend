'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Usuario', {
      Id_usuario: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      PK_fk_Id_tdoc: {
        type: Sequelize.INTEGER
      },
      Numero_documento: {
        type: Sequelize.INTEGER
      },
      Primer_nombre: {
        type: Sequelize.STRING
      },
      Segundo_nombre: {
        type: Sequelize.STRING
      },
      Primer_apellido: {
        type: Sequelize.STRING
      },
      Segundo_apellido: {
        type: Sequelize.STRING
      },
      Telefono_contacto: {
        type: Sequelize.INTEGER
      },
      Email: {
        type: Sequelize.STRING
      },
      Pk_fk_Id_Cod_rol: {
        type: Sequelize.INTEGER
      },
      Clave: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Usuario');
  }
};