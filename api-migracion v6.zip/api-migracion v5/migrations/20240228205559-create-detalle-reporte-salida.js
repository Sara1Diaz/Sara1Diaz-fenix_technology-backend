'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('DetalleReporteSalida', {
      Id_Detalle_reporte_salida: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      PK_fk_Id_salida: {
        type: Sequelize.INTEGER
      },
      PK_fk_Id_bodega: {
        type: Sequelize.INTEGER
      },
      PK_fk_Id_producto: {
        type: Sequelize.INTEGER
      },
      Cantidad_total_salidas: {
        type: Sequelize.INTEGER
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('DetalleReporteSalida');
  }
};