'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('DetalleDevolucionLocal', {
      Id_detalle_devolucion: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      PK_fk_Id_devolucion: {
        type: Sequelize.INTEGER
      },
      PK_fk_Id_bodega_destino: {
        type: Sequelize.INTEGER
      },
      PK_fk_Id_producto: {
        type: Sequelize.INTEGER
      },
      Cantidad_devuelta: {
        type: Sequelize.INTEGER
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('DetalleDevolucionLocal');
  }
};