'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('DetalleReporteEntrada', {
      Id_Detalle_reporte_entrada: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      PK_fk_Id_entrada: {
        type: Sequelize.INTEGER
      },
      PK_fk_Id_bodega_destino: {
        type: Sequelize.INTEGER
      },
      PK_fk_Id_producto: {
        type: Sequelize.INTEGER
      },
      Cantidad_total_entradas: {
        type: Sequelize.INTEGER
      },
      Valor_entradas: {
        type: Sequelize.BIGINT
      },
      Subtotal_entradas: {
        type: Sequelize.BIGINT
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('DetalleReporteEntrada');
  }
};