'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Envio', {
      Id_envio:{
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      Pk_fk_id_pedido: {
        type: Sequelize.INTEGER
      },
      Tipo_envio: {
        type: Sequelize.STRING
      },
      Nom_transportadora: {
        type: Sequelize.STRING
      },
      Ciudad_envio: {
        type: Sequelize.STRING
      },
      Direccion_entrega: {
        type: Sequelize.STRING
      },
      Valor_envio: {
        type: Sequelize.BIGINT
      },
      Fecha_estimada_entrega_pedido: {
        type: Sequelize.DATE
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Envio');
  }
};