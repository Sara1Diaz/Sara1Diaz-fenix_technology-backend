'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('ReportePedido', {
      Id_pedido: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      Pk_fk_numlocal: {
        type: Sequelize.INTEGER
      },
      Pk_fk_Id_envio: {
        type: Sequelize.INTEGER
      },
      Fecha_emision: {
        type: Sequelize.DATE
      },
      Nombre_cliente: {
        type: Sequelize.STRING
      },
      Apellido_cliente: {
        type: Sequelize.STRING
      },
      Telefono_cliente: {
        type: Sequelize.INTEGER
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('ReportePedido');
  }
};