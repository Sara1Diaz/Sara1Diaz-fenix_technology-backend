'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('DetalleReportePedido', {
      Id_detalle_pedido: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      Pk_fk_id_pedido: {
        type: Sequelize.INTEGER
      },
      Metodo_pago: {
        type: Sequelize.STRING
      },
      Pk_fk_idproducto: {
        type: Sequelize.INTEGER
      },
      Cantidad_producto: {
        type: Sequelize.INTEGER
      },
      Valor_producto: {
        type: Sequelize.BIGINT
      },
      Total_pedido: {
        type: Sequelize.INTEGER
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('DetalleReportePedido');
  }
};